package com.electronwill.nightconfig.core;

import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.function.BiFunction;
import java.util.function.Function;
import java.util.function.Supplier;

public final class ConfigCopier {
	private final Function<Object, Object> plainValueCopier;
	private final BiFunction<Collection<?>, CommentedConfig, Collection<Object>> collectionCopier;

	public ConfigCopier(Function<Object, Object> plainValueCopier, BiFunction<Collection<?>, CommentedConfig, Collection<Object>> collectionCopier) {
		this.plainValueCopier = plainValueCopier;
		this.collectionCopier = collectionCopier;
	}

	public void deepCopy(UnmodifiableConfig config, Supplier<Config> copyCreator) {

	}

	private void deepCopyTo(UnmodifiableCommentedConfig from, CommentedConfig to) {
		for (UnmodifiableCommentedConfig.Entry entry : from.entrySet()) {
			// get the key
			String key = entry.getKey();
			List<String> configKey = Collections.singletonList(key);

			// copy the value
			Object value = entry.getValue();
			Object copiedValue;
			if (value instanceof UnmodifiableConfig) {
				// copy recursively!
				CommentedConfig toSub = to.createSubConfig();
				deepCopyTo(UnmodifiableCommentedConfig.fake((UnmodifiableConfig) value), toSub);
				copiedValue = toSub;
			} else if (value instanceof Collection) {
				// copy recursively!
				copiedValue = collectionCopier.apply((Collection<?>) value, to);
			} else {
				// "plain" copy
				copiedValue = plainValueCopier.apply(value);
			}
			to.set(configKey, copiedValue);

			// copy the comment, if any (Strings are immutable)
			String comment = entry.getComment();
			if (comment != null) {
				to.setComment(configKey, comment);
			}
		}
	}

	private static final class Builder {
		// ...
	}
}
